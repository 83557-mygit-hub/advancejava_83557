package com.sunbeam.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sunbeam.daos.CandidateDao;
import com.sunbeam.daos.CandidateDaoImpl;

@WebServlet("/delcand")
public class DeleteCandidateServlet extends HttpServlet {
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	String idstr=req.getParameter("id");
	int id=Integer.parseInt(idstr);
	try(CandidateDao canDao=new CandidateDaoImpl()){
		int count=canDao.deleteById(id);
		String message="candidate deleted : "+ count;
		req.setAttribute("message", message);
		RequestDispatcher rd=req.getRequestDispatcher("result");
		rd.forward(req, resp);
	}catch(Exception e) {
		e.printStackTrace();
		throw new ServletException();
	}
	}
}
